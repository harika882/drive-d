from django.apps import AppConfig


class ShortenersiteConfig(AppConfig):
    name = 'shortenersite'
