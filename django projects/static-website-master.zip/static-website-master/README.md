<div align="center"> <h1> Django Static-Website Project </h1> </div>
<div align="center"> python static website example </div>


## instruction for run this project

-First of all, clone this project using following command

```
$ git clone https://github.com/rahulcs754/static-website.git
```
